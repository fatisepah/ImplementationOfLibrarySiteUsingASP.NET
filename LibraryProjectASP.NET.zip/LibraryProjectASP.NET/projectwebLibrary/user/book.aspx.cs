﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
public partial class sabt_bimeh : System.Web.UI.Page
{
    string constr = "Data Source=nanoo-pc;Initial Catalog=book;Integrated Security=True";
    string cmdstr;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        GridView1.Visible = true;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
       
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        SqlConnection con1 = new SqlConnection(constr);
        try
        {
            con1.Open();
            cmdstr = "select * from book where bookid ='" + TextBox1.Text + "'";
            SqlCommand cmd = new SqlCommand(cmdstr, con1);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                TextBox2.Text = Convert.ToString(dr["namebook"]);
                TextBox3.Text = Convert.ToString(dr["writer"]);
                TextBox4.Text = Convert.ToString(dr["price"]);
            }
            else
            {
                Label9.Font.Bold = true;
                Label9.Text = "رکورد مورد نظر یافت نشد.";
            }
            con1.Close();

        }
        catch (Exception ex)
        {
            Label9.Text = Convert.ToString(ex.Message);
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {

          
       
          }
    protected void Button4_Click(object sender, EventArgs e)
    { }
    protected void Button10_Click(object sender, EventArgs e)
    {
        SqlConnection con1 = new SqlConnection(constr);

        try
        {
            con1.Open();

            cmdstr = "insert into book(bookid,namebook,writer,price)values('" + TextBox1.Text + "',N'" + TextBox2.Text + "',N'" + TextBox3.Text + "','" + TextBox4.Text + "')";
            SqlCommand cmd = new SqlCommand(cmdstr, con1);
            cmd.ExecuteNonQuery();
            Label9.Font.Bold = false;
            Label9.Text = "اطلاعات ثبت شد.";
            con1.Close();

        }
        catch (SqlException e1)
        {
            Label1.Text = Convert.ToString(e1.Message);
        }
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
    }
    protected void Button11_Click(object sender, EventArgs e)
    {
        SqlConnection con1 = new SqlConnection(constr);
        try
        {
            con1.Open();
            cmdstr = "update book set namebook=N'" + TextBox2.Text + "',writer=N'" + TextBox3.Text + "',price=N'" + TextBox4.Text + "' where bookid =N'" + TextBox1.Text + "'";
            SqlCommand cmd = new SqlCommand(cmdstr, con1);
            cmd.ExecuteNonQuery();
            Label1.Font.Bold = false;

            con1.Close();
            Label1.Visible = true;
            Label1.Text = "تغییرات ثبت شد.";

        }
        catch (SqlException e1)
        {
            Label1.Visible = true;
            Label1.Text = Convert.ToString(e1.Message);
        }
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
    }
    protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}
    