﻿using System;
using System.Collections;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Data;



   
public partial class AddB : System.Web.UI.Page
{
    string constr = "Data Source=nanoo-pc;Initial Catalog=book;Integrated Security=True";
    string cmdstr;
    
     
    protected void Button8_Click(object sender, EventArgs e)
    {
        Label4.Visible = true;
        gridview1.Visible = true;
        
        
    }
    protected void Button9_Click(object sender, EventArgs e)
    {
        SqlConnection con1 = new SqlConnection(constr);

        try
        {
            con1.Open();
         
            cmdstr = "insert into sefarsh(orderid,ordername,kala,price)values(N'" + TextBox1.Text + "',N'" + TextBox2.Text + "',N'" + TextBox3.Text + "',N'" + TextBox4.Text + "')";
            SqlCommand cmd = new SqlCommand(cmdstr, con1);
            cmd.ExecuteNonQuery();
            con1.Close();
            Label6.Visible = true;
            Label6.Text = "اطلاعات ثبت شد.";
        }
        catch (SqlException e1)
        {
            Label6.Visible = true;
            Label6.Text = Convert.ToString(e1.Message);
        }
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
        
    }
    protected void Button6_Click(object sender, EventArgs e)
    {
        SqlConnection con1 = new SqlConnection(constr);
        try
        {
            con1.Open();
            cmdstr = "select * from sefarsh where orderid='" + TextBox1.Text + "'";
            SqlCommand cmd = new SqlCommand(cmdstr, con1);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                TextBox2.Text = Convert.ToString(dr["ordername"]);
                TextBox3.Text = Convert.ToString(dr["kala"]);
                TextBox4.Text = Convert.ToString(dr["price"]);
                Label6.Visible = true;
                Label6.Text = "اطلاعات یافت شد.";
            }
            else
            {
                Label6.Visible = true;
                Label6.Text = "اطلاعات یافت نشد.";
            }
            con1.Close();

        }
        catch (Exception ex)
        {
            Label6.Text = Convert.ToString(ex.Message);
        }
    }
    protected void Button10_Click(object sender, EventArgs e)
    {
        SqlConnection con1 = new SqlConnection(constr);
        try
        {
            con1.Open();
            cmdstr = "update sefarsh set ordername=N'" + TextBox2.Text + "',kala=N'"+TextBox3.Text+"',price=N'"+ TextBox4.Text + "' where orderid =N'" + TextBox1.Text + "'";
            SqlCommand cmd = new SqlCommand(cmdstr, con1);
            cmd.ExecuteNonQuery();
            Label6.Font.Bold = false;

            con1.Close();
            Label6.Visible = true;
            Label6.Text = "تغییرات ثبت شد.";

        }
        catch (SqlException e1)
        {
            Label6.Visible = true;
            Label6.Text = Convert.ToString(e1.Message);
        }
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
       
     
    }
    }

    

