﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
public partial class sabt_kala : System.Web.UI.Page
{
    string constr = "Data Source=nanoo-pc;Initial Catalog=book;Integrated Security=True";
    string cmdstr;
        protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        SqlConnection con1 = new SqlConnection(constr);
        try
        {
            con1.Open();
            cmdstr = "select * from custom where custid='" + TextBox1.Text + "'";
            SqlCommand cmd = new SqlCommand(cmdstr, con1);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                TextBox2.Text = Convert.ToString(dr["name"]);
                TextBox3.Text = Convert.ToString(dr["address"]);
                TextBox4.Text = Convert.ToString(dr["city"]);
                TextBox5.Text = Convert.ToString(dr["tel"]);
                Label1.Visible = true;
                Label10.Text = "اطلاعات یافت شد.";
            }
            else
            {
                Label1.Visible = true;
                Label10.Text = "اطلاعات یافت نشد.";
            }
            con1.Close();

        }
        catch (Exception ex)
        {
            Label1.Text = Convert.ToString(ex.Message);
        }
        
        
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
       
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
       

    }
    protected void Button4_Click1(object sender, EventArgs e)
    {
        GridView1.Visible = true;
        Label6.Visible = true;

    }
    protected void Button5_Click1(object sender, EventArgs e)
    {
        SqlConnection con1 = new SqlConnection(constr);

        try
        {
            con1.Open();
            
            cmdstr = "insert into custom(custid,name,address,city,tel)values(N'" + TextBox1.Text + "',N'" + TextBox2.Text + "',N'" + TextBox3.Text + "',N'" + TextBox4.Text + "',N'" + TextBox5.Text + "')";
            SqlCommand cmd = new SqlCommand(cmdstr, con1);
            cmd.ExecuteNonQuery();
            con1.Close();
            Label1.Visible = true;
            Label10.Text = "اطلاعات ثبت شد.";
        }
        catch (SqlException e1)
        {
            Label10.Visible = true;
            Label10.Text = Convert.ToString(e1.Message);
        }
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
        TextBox5.Text = "";
    }
    protected void Button6_Click(object sender, EventArgs e)
    {
        SqlConnection con1 = new SqlConnection(constr);
        try
        {
           con1.Open();
            cmdstr = "update custom set name=N'" + TextBox2.Text + "',address=N'" + TextBox3.Text + "',city=N'" + TextBox4.Text + "' ,tel=N'" + TextBox5.Text + "'where custid =N'" + TextBox1.Text + "'";
            SqlCommand cmd = new SqlCommand(cmdstr, con1);
            cmd.ExecuteNonQuery();
            Label1.Font.Bold = false;

            con1.Close();
            Label10.Visible = true;
            Label10.Text = "تغییرات ثبت شد.";

        }
        catch (SqlException e1)
        {
            Label1.Visible = true;
            Label10.Text = Convert.ToString(e1.Message);
        }
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
         TextBox5.Text = "";
    }
}