﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
public partial class log : System.Web.UI.Page
{
    string constr = "Data Source=nanoo-pc;Initial Catalog=book;Integrated Security=True";
    string cmdstr;
    SqlConnection con1;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {

        SqlConnection con1 = new SqlConnection(constr);
        try
        {
            con1.Open();
            cmdstr = "select * from karbar where username=N'" + TextBox1.Text + "'and password= '" + TextBox2.Text + "'";
            SqlCommand cmd = new SqlCommand(cmdstr, con1);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                Session["username"] = Convert.ToString(dr["username"]);
                Response.Redirect("default.aspx");
            } 
            else
            {
                Label1.Visible = true;
                Label1.Text = "اطلاعات یافت نشد.";
            }
            con1.Close();

        }
        catch (Exception ex)
        {
            Label2.Text = Convert.ToString(ex.Message);
        }
    }
}