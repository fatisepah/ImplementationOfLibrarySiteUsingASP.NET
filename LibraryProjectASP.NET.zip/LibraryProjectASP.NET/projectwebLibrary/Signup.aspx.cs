﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Data.SqlClient;
using System.Data;

public partial class Signup : System.Web.UI.Page
{
    string constr = "Data Source=nanoo-pc;Initial Catalog=book;Integrated Security=True";
    string cmdstr;
    protected void Button1_Click1(object sender, EventArgs e)
    {
        SqlConnection con1 = new SqlConnection(constr);

        try
        {
            con1.Open();
            
            cmdstr = "insert into karbar(username,password,name,family)values(N'" + TextBox3.Text + "',N'" + TextBox4.Text + "',N'" + TextBox1.Text + "',N'"+TextBox2.Text+ "')";
            SqlCommand cmd = new SqlCommand(cmdstr, con1);
            cmd.ExecuteNonQuery();
            Label6.Font.Bold = false;
            Label6.Text = "اطلاعات ثبت شد.";
            con1.Close();

        }
        catch (SqlException e1)
        {
            Label6.Text = Convert.ToString(e1.Message);
        }
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
       
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        SqlConnection con1 = new SqlConnection(constr);
        try
        {
            con1.Open();
            cmdstr = "select * from karbar where username=N'" + TextBox3.Text + "' and password=N'" + TextBox4.Text + "'";
            SqlCommand cmd = new SqlCommand(cmdstr, con1);
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                TextBox4.Text = Convert.ToString(dr["password"]);
                TextBox1.Text = Convert.ToString(dr["name"]);
                TextBox2.Text = Convert.ToString(dr["family"]);
             
            }
            else
            {
                Label6.Text = "فرد به این مشخصات یافت نشد.";
            }
            con1.Close();

        }
        catch (Exception ex)
        {
            Label6.Text = Convert.ToString(ex.Message);
        }

            }
    protected void Button3_Click(object sender, EventArgs e)
    {
        SqlConnection con1 = new SqlConnection(constr);
        try
        {
            con1.Open();
            cmdstr = "update karbar set  family =N'"+TextBox2.Text+"' , username='"+TextBox3.Text +"',password='"+TextBox4 .Text +"'  where name='" + TextBox1.Text + "'";
            SqlCommand cmd = new SqlCommand(cmdstr, con1);
            cmd.ExecuteNonQuery();
            Label6.Font.Bold = false;
            con1.Close();
            Label6.Text = "تغییرات اعمال شد.";

        }
        catch (SqlException e1)
        {
            Label6.Text = Convert.ToString(e1.Message);
        }
        TextBox3.Text = " ";
        TextBox4.Text = " ";
      
        
    }
}

    

